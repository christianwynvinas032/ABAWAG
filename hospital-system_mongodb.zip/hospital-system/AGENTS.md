<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Signed-in pages live under src/routes/_authenticated/ and read data via the browser client with RLS; roles (admin/hr/staff) live in user_roles and audit_logs is filled by database triggers — keeps permissions enforced server-side.
- Change roles only through the authenticated assign_user_role database function; it checks administrator access and replaces roles atomically to avoid roleless accounts.
- Data lives in MongoDB (db from MONGODB_DB, default hospital_management); the browser calls only /api/db and /api/auth, which enforce roles server-side in src/server/handlers.server.ts — keeps permissions off the client.
- Build for Render with the node-server Nitro preset; the MongoDB driver needs Node, not Workers.
- Audit triggers shared across different tables must access optional record fields through JSON or table-specific branches to avoid errors on tables without those fields.
- Shared database result handling must throw read errors rather than substitute empty records, and CSV export must escape fields and neutralize formula prefixes to preserve records safely.
