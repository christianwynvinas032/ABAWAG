# Hospital system — MongoDB migration
- [x] MongoDB Atlas (hospital_management) + bcrypt login sessions
- [x] Auto-create admin@hospital.com from ADMIN_PASSWORD; create-admin script
- [x] Fix "employeeId is required" — auto-generated unique EMP-###### IDs
- [x] Collections: administrators, employees, departments, incidents, maintenance (+ attendance, leave, audit)
- [x] Render node-server build + render.yaml
- [x] Tested admin login, employee registration, saving, permissions on a real MongoDB
- [ ] Live check on Render — needs owner's MONGODB_URI / ADMIN_PASSWORD in Render
