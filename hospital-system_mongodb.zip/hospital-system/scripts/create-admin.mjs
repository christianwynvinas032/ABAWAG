// Set or reset the Hospital Administrator password (bcrypt-hashed) in MongoDB.
// Usage: MONGODB_URI="mongodb+srv://..." npm run create-admin
import { MongoClient } from "mongodb";
import bcrypt from "bcryptjs";
import { randomUUID } from "node:crypto";
import readline from "node:readline";

const uri = process.env.MONGODB_URI;
if (!uri) { console.error("Set MONGODB_URI first."); process.exit(1); }
const email = (process.env.ADMIN_EMAIL || "admin@hospital.com").toLowerCase();
const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const ask = (q) => new Promise((r) => rl.question(q, r));
const password = process.env.ADMIN_PASSWORD || (await ask(`New password for ${email} (min 8 chars): `));
rl.close();
if (password.length < 8) { console.error("Password must be at least 8 characters."); process.exit(1); }
const client = await MongoClient.connect(uri);
const db = client.db(process.env.MONGODB_DB || "hospital_management");
await db.collection("administrators").updateOne(
  { email },
  { $set: { password_hash: await bcrypt.hash(password, 12), role: "admin" },
    $setOnInsert: { id: randomUUID(), email, full_name: "Hospital Administrator", created_at: new Date().toISOString() } },
  { upsert: true },
);
console.log(`Administrator ${email} saved in database "${db.databaseName}".`);
await client.close();
