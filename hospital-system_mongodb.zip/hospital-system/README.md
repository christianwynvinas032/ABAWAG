# Hospital Management System (MongoDB Atlas + Render)

## 1. MongoDB Atlas
1. Atlas → Database → Connect → Drivers → copy the connection string.
2. Atlas → Network Access → add `0.0.0.0/0` (Render uses changing IPs).
3. Nothing to create by hand: on first start the app creates the database
   **hospital_management** with collections `administrators, employees,
   departments, incidents, maintenance, attendance, leave_applications,
   audit_logs, counters` and their indexes.

## 2. Render (Web Service → Environment)
| Variable | Value |
|---|---|
| `MONGODB_URI` | your Atlas connection string |
| `MONGODB_DB` | `hospital_management` |
| `ADMIN_EMAIL` | `admin@hospital.com` |
| `ADMIN_PASSWORD` | the administrator password you choose (min 8 chars) |
| `SESSION_SECRET` | any long random string |

Build command: `npm install && npm run build` · Start command: `npm start`
(`render.yaml` holds the same settings.)

On first start the administrator `admin@hospital.com` is created with a
bcrypt-hashed password. To change it later: set the new `ADMIN_PASSWORD` plus
`ADMIN_RESET_PASSWORD=true` for one deploy (then remove it), or run
`MONGODB_URI="..." npm run create-admin`.

## Employee IDs
Each registered employee automatically gets a unique `employeeId`
(`EMP-000001`, `EMP-000002`, …) from an atomic counter with a unique index.
