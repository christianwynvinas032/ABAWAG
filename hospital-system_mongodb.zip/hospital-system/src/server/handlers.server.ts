import type { Db, Document } from "mongodb";
import bcrypt from "bcryptjs";
import { randomUUID } from "node:crypto";
import { nextEmployeeId } from "./mongo.server";
import type { SessionUser } from "./session.server";

type Result = { data: unknown; error: { message: string } | null; count?: number | null; status?: number };
const fail = (message: string, status = 400): Result => ({ data: null, error: { message }, status });

/** Table names used by the pages → MongoDB collections. */
const COLLECTION: Record<string, string> = {
  employees: "employees",
  attendance: "attendance",
  leave_applications: "leave_applications",
  leak_reports: "incidents",
  audit_logs: "audit_logs",
  profiles: "administrators",
  user_roles: "administrators",
  departments: "departments",
  maintenance: "maintenance",
};

const MODULE: Record<string, string> = {
  employees: "Employee Management",
  attendance: "Attendance Management",
  leave_applications: "Leave Management",
  leak_reports: "Leak Detection",
};

/** Columns each table may receive from the browser (everything else is ignored). */
const WRITABLE: Record<string, string[]> = {
  employees: ["first_name", "last_name", "department", "position", "email", "contact"],
  attendance: ["employee_id", "date", "time_in", "time_out", "status"],
  leave_applications: ["leave_type", "start_date", "end_date", "reason", "status"],
  leak_reports: ["location", "description", "status"],
};

const isManager = (u: SessionUser) => u.role === "admin" || u.role === "hr";
const KEY = /^[a-z_A-Z]+$/;
const primitive = (v: unknown) => v === null || ["string", "number", "boolean"].includes(typeof v);

function pick(table: string, values: Record<string, unknown>) {
  const out: Record<string, unknown> = {};
  for (const k of WRITABLE[table] ?? []) {
    if (k in values && primitive(values[k])) out[k] = typeof values[k] === "string" ? (values[k] as string).trim() : values[k];
  }
  return out;
}

export type Filt = { col: string; op: "eq" | "neq"; val: unknown };
export type DbRequest = {
  table: string;
  op: "select" | "insert" | "update";
  count?: boolean;
  head?: boolean;
  filters?: Filt[];
  order?: { col: string; ascending: boolean } | null;
  limit?: number | null;
  values?: Record<string, unknown>;
  join?: boolean;
};

function buildFilter(filters: Filt[] = []): Record<string, any> | null {
  const f: Record<string, unknown> = {};
  for (const x of filters) {
    if (!KEY.test(x.col) || !primitive(x.val)) return null;
    f[x.col] = x.op === "eq" ? x.val : { $ne: x.val };
  }
  return f;
}

async function audit(db: Db, user: SessionUser, action: string, module: string, record_id: string | null = null) {
  await db.collection("audit_logs").insertOne({
    id: randomUUID(), user_id: user.id, user_email: user.email, action, module, record_id, created_at: new Date().toISOString(),
  });
}

export async function handleDb(db: Db, user: SessionUser, req: DbRequest): Promise<Result> {
  const table = req.table;
  const coll = COLLECTION[table];
  if (!coll) return fail("Unknown table");
  const filter = buildFilter(req.filters);
  if (!filter) return fail("Invalid filter");
  const c = db.collection(coll);

  if (req.op === "select") {
    let scope: Record<string, unknown> = {};
    let projection: Document = { _id: 0 };
    if (table === "attendance" && !isManager(user)) return fail("Only HR or administrators can view attendance", 403);
    if (table === "audit_logs" && user.role !== "admin") return fail("Administrators only", 403);
    if (table === "leave_applications" && !isManager(user)) scope = { user_id: user.id };
    if (table === "profiles") {
      projection = { _id: 0, password_hash: 0, role: 0 };
      if (!isManager(user)) scope = { id: user.id };
    }
    if (table === "user_roles") {
      projection = { _id: 0, user_id: "$id", role: 1 };
      if (user.role !== "admin") scope = { id: user.id };
      if ("user_id" in filter) { filter.id = filter.user_id; delete filter.user_id; }
    }
    const q = { ...filter, ...scope };
    if (req.head) return { data: null, error: null, count: await c.countDocuments(q) };
    let cursor = c.find(q, { projection });
    if (req.order && KEY.test(req.order.col)) cursor = cursor.sort({ [req.order.col]: req.order.ascending ? 1 : -1 });
    if (req.limit) cursor = cursor.limit(Math.min(Number(req.limit), 1000));
    const rows: any[] = await cursor.toArray();
    if (table === "attendance" && req.join) {
      const ids = [...new Set(rows.map((r) => r.employee_id))];
      const emps = await db.collection("employees").find({ id: { $in: ids } }, { projection: { _id: 0, id: 1, employee_no: 1, employeeId: 1, first_name: 1, last_name: 1 } }).toArray();
      for (const r of rows) r.employees = emps.find((e) => e.id === r.employee_id) ?? null;
    }
    return { data: rows, error: null, count: req.count ? rows.length : null };
  }

  const values = req.values && typeof req.values === "object" ? req.values : {};
  const now = new Date().toISOString();

  if (req.op === "insert") {
    let doc: Record<string, unknown> = { ...pick(table, values), id: randomUUID(), created_at: now };
    if (table === "employees") {
      if (!isManager(user)) return fail("Only HR or administrators can register employees", 403);
      for (const k of ["first_name", "last_name", "department", "position"]) if (!doc[k]) return fail(`${k.replace("_", " ")} is required`);
      const employeeId = await nextEmployeeId(db);
      doc = { ...doc, employeeId, employee_no: employeeId, email: doc.email || null, contact: doc.contact || null, updated_at: now };
      await db.collection("departments").updateOne({ name: doc.department }, { $setOnInsert: { id: randomUUID(), name: doc.department, created_at: now } }, { upsert: true });
    } else if (table === "attendance") {
      if (!isManager(user)) return fail("Only HR or administrators can record attendance", 403);
      if (!doc.employee_id || !(await db.collection("employees").findOne({ id: doc.employee_id }))) return fail("Select a valid employee");
      if (!doc.date) return fail("date is required");
    } else if (table === "leave_applications") {
      if (!doc.start_date || !doc.end_date) return fail("Start and end dates are required");
      doc = { ...doc, user_id: user.id, applicant_email: user.email, status: "pending" };
    } else if (table === "leak_reports") {
      if (!doc.location || !doc.description) return fail("Location and description are required");
      doc = { ...doc, reported_by: user.id, reporter_email: user.email, status: "reported", updated_at: now };
    } else return fail("Insert not allowed", 403);
    await c.insertOne(doc);
    await audit(db, user, "INSERT", MODULE[table] ?? table, doc.id as string);
    const { _id, ...clean } = doc as Record<string, unknown> & { _id?: unknown };
    void _id;
    return { data: [clean], error: null };
  }

  if (req.op === "update") {
    if (!isManager(user)) return fail("Only HR or administrators can update records", 403);
    if (!WRITABLE[table]) return fail("Update not allowed", 403);
    if (!filter.id) return fail("Record id is required");
    const set: Record<string, any> = { ...pick(table, values), updated_at: now };
    const before: any = await c.findOne(filter);
    if (!before) return fail("Record not found", 404);
    await c.updateOne(filter, { $set: set });
    if (table === "employees" && set.department) {
      await db.collection("departments").updateOne({ name: set.department }, { $setOnInsert: { id: randomUUID(), name: set.department, created_at: now } }, { upsert: true });
    }
    if (table === "leak_reports" && set.status && set.status !== before.status) {
      await db.collection("maintenance").insertOne({
        id: randomUUID(), incident_id: before.id, location: before.location, from_status: before.status, to_status: set.status,
        handled_by: user.email, created_at: now,
      });
    }
    await audit(db, user, "UPDATE", MODULE[table] ?? table, before.id);
    return { data: null, error: null };
  }
  return fail("Unsupported operation");
}

export async function handleRpc(db: Db, user: SessionUser, fn: string, args: Record<string, unknown>): Promise<Result> {
  if (fn === "log_activity") {
    await audit(db, user, String(args._action ?? "").slice(0, 200), String(args._module ?? "").slice(0, 100));
    return { data: null, error: null };
  }
  if (fn === "assign_user_role") {
    if (user.role !== "admin") return fail("Administrators only", 403);
    const role = args._role;
    if (!["admin", "hr", "staff"].includes(role as string)) return fail("Invalid role");
    if (args._user_id === user.id && role !== "admin") return fail("You can't remove your own administrator role.");
    const r = await db.collection("administrators").updateOne({ id: String(args._user_id) }, { $set: { role } });
    if (!r.matchedCount) return fail("User not found", 404);
    await audit(db, user, `Assigned role ${role}`, "User Management", String(args._user_id));
    return { data: null, error: null };
  }
  return fail("Unknown function");
}

export async function signIn(db: Db, email: string, password: string) {
  const u = await db.collection("administrators").findOne({ email: String(email).trim().toLowerCase() });
  if (!u || !u.password_hash || !(await bcrypt.compare(String(password), u.password_hash))) return null;
  return u.id as string;
}

export async function signUp(db: Db, email: string, password: string, fullName: string) {
  const e = String(email).trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e)) throw new Error("Enter a valid email address");
  if (String(password).length < 8) throw new Error("Password must be at least 8 characters");
  if (await db.collection("administrators").findOne({ email: e })) throw new Error("An account with this email already exists");
  const id = randomUUID();
  await db.collection("administrators").insertOne({
    id, email: e, full_name: String(fullName || "").trim(), role: "staff",
    password_hash: await bcrypt.hash(String(password), 12), created_at: new Date().toISOString(),
  });
  return id;
}
