import { createHmac, createHash, timingSafeEqual } from "node:crypto";
import type { Db } from "mongodb";

const COOKIE = "hms_session";
const MAX_AGE = 60 * 60 * 12; // 12 hours

function secret() {
  const s = process.env.SESSION_SECRET || (process.env.MONGODB_URI ? createHash("sha256").update("hms:" + process.env.MONGODB_URI).digest("hex") : "");
  if (!s) throw new Error("SESSION_SECRET is not set.");
  return s;
}

function sign(data: string) {
  return createHmac("sha256", secret()).update(data).digest("base64url");
}

export function createSessionCookie(userId: string) {
  const payload = Buffer.from(JSON.stringify({ uid: userId, exp: Date.now() + MAX_AGE * 1000 })).toString("base64url");
  const token = `${payload}.${sign(payload)}`;
  const secure = process.env.NODE_ENV === "production" ? "; Secure" : "";
  return `${COOKIE}=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${MAX_AGE}${secure}`;
}

export function clearSessionCookie() {
  return `${COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0`;
}

function readUserId(request: Request): string | null {
  const cookie = request.headers.get("cookie") ?? "";
  const match = cookie.split(/;\s*/).find((c) => c.startsWith(COOKIE + "="));
  if (!match) return null;
  const [payload, sig] = match.slice(COOKIE.length + 1).split(".");
  if (!payload || !sig) return null;
  const expected = Buffer.from(sign(payload));
  const given = Buffer.from(sig);
  if (expected.length !== given.length || !timingSafeEqual(expected, given)) return null;
  try {
    const { uid, exp } = JSON.parse(Buffer.from(payload, "base64url").toString());
    if (typeof uid !== "string" || Date.now() > exp) return null;
    return uid;
  } catch {
    return null;
  }
}

export type SessionUser = { id: string; email: string; full_name: string; role: "admin" | "hr" | "staff" };

export async function getSessionUser(db: Db, request: Request): Promise<SessionUser | null> {
  const uid = readUserId(request);
  if (!uid) return null;
  const u = await db.collection("administrators").findOne({ id: uid }, { projection: { _id: 0, password_hash: 0 } });
  return (u as unknown as SessionUser) ?? null;
}
