import { MongoClient, type Db } from "mongodb";
import bcrypt from "bcryptjs";
import { randomUUID } from "node:crypto";

export const DB_NAME = process.env.MONGODB_DB || "hospital_management";
export const ADMIN_EMAIL = (process.env.ADMIN_EMAIL || "admin@hospital.com").toLowerCase();

/** Collections the system needs; created (with indexes) on first connection. */
export const COLLECTIONS = [
  "administrators",
  "employees",
  "departments",
  "incidents",
  "maintenance",
  "attendance",
  "leave_applications",
  "audit_logs",
  "counters",
] as const;

let dbPromise: Promise<Db> | null = null;

export function getDb(): Promise<Db> {
  if (!dbPromise) {
    dbPromise = (async () => {
      const uri = process.env.MONGODB_URI;
      if (!uri) throw new Error("MONGODB_URI is not set. Add it to your Render environment variables.");
      const client = new MongoClient(uri, { serverSelectionTimeoutMS: 10000 });
      await client.connect();
      const db = client.db(DB_NAME);
      await initDatabase(db);
      return db;
    })().catch((err) => {
      dbPromise = null; // allow retry on next request
      throw err;
    });
  }
  return dbPromise;
}

export async function initDatabase(db: Db) {
  const existing = new Set((await db.listCollections({}, { nameOnly: true }).toArray()).map((c) => c.name));
  for (const name of COLLECTIONS) if (!existing.has(name)) await db.createCollection(name);

  await Promise.all([
    db.collection("administrators").createIndex({ email: 1 }, { unique: true }),
    db.collection("administrators").createIndex({ id: 1 }, { unique: true }),
    db.collection("employees").createIndex({ id: 1 }, { unique: true }),
    db.collection("employees").createIndex({ employeeId: 1 }, { unique: true }),
    db.collection("departments").createIndex({ name: 1 }, { unique: true }),
    db.collection("incidents").createIndex({ id: 1 }, { unique: true }),
    db.collection("maintenance").createIndex({ incident_id: 1 }),
    db.collection("attendance").createIndex({ id: 1 }, { unique: true }),
    db.collection("attendance").createIndex({ employee_id: 1, date: 1 }),
    db.collection("leave_applications").createIndex({ id: 1 }, { unique: true }),
    db.collection("audit_logs").createIndex({ created_at: -1 }),
  ]);

  await ensureAdministrator(db);
}

/** Creates admin@hospital.com from ADMIN_PASSWORD if it doesn't exist yet. */
export async function ensureAdministrator(db: Db) {
  const password = process.env.ADMIN_PASSWORD;
  const admins = db.collection("administrators");
  const existing = await admins.findOne({ email: ADMIN_EMAIL });
  if (existing) {
    if (password && process.env.ADMIN_RESET_PASSWORD === "true") {
      await admins.updateOne({ email: ADMIN_EMAIL }, { $set: { password_hash: await bcrypt.hash(password, 12), role: "admin" } });
    }
    return;
  }
  if (!password) {
    console.warn(`[hospital] No administrator yet. Set ADMIN_PASSWORD to create ${ADMIN_EMAIL}.`);
    return;
  }
  await setAdminPassword(db, password);
}

export async function setAdminPassword(db: Db, password: string, email = ADMIN_EMAIL, fullName = "Hospital Administrator") {
  if (password.length < 8) throw new Error("Administrator password must be at least 8 characters.");
  const hash = await bcrypt.hash(password, 12);
  await db.collection("administrators").updateOne(
    { email: email.toLowerCase() },
    {
      $set: { password_hash: hash, role: "admin" },
      $setOnInsert: { id: randomUUID(), email: email.toLowerCase(), full_name: fullName, created_at: new Date().toISOString() },
    },
    { upsert: true },
  );
}

/** Atomic, gap-free sequence → EMP-000001, EMP-000002, ... */
export async function nextEmployeeId(db: Db): Promise<string> {
  const res = await db
    .collection<{ _id: string; seq: number }>("counters")
    .findOneAndUpdate({ _id: "employeeId" }, { $inc: { seq: 1 } }, { upsert: true, returnDocument: "after" });
  const seq = res?.seq ?? 1;
  return `EMP-${String(seq).padStart(6, "0")}`;
}
