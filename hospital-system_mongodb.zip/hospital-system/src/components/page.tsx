import type { ReactNode } from "react";
import { Badge } from "@/components/ui/badge";

export function PageHeader({ title, subtitle, action }: { title: string; subtitle?: string; action?: ReactNode }) {
  return (
    <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
      <div>
        <h1 className="text-3xl">{title}</h1>
        {subtitle && <p className="mt-1 text-sm text-muted-foreground">{subtitle}</p>}
      </div>
      {action && <div className="no-print">{action}</div>}
    </div>
  );
}

const tone: Record<string, string> = {
  approved: "bg-success/15 text-success",
  resolved: "bg-success/15 text-success",
  present: "bg-success/15 text-success",
  pending: "bg-warning/20 text-accent-foreground",
  investigating: "bg-warning/20 text-accent-foreground",
  late: "bg-warning/20 text-accent-foreground",
  rejected: "bg-destructive/15 text-destructive",
  reported: "bg-destructive/15 text-destructive",
  absent: "bg-destructive/15 text-destructive",
  on_leave: "bg-secondary text-secondary-foreground",
};

export function StatusBadge({ value }: { value: string }) {
  return (
    <Badge variant="outline" className={`border-0 font-mono text-xs uppercase ${tone[value] ?? ""}`}>
      {value.replace("_", " ")}
    </Badge>
  );
}

export function NoAccess() {
  return <p className="text-muted-foreground">You don't have access to this module.</p>;
}
