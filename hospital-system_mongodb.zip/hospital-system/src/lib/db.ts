// Browser data client. Same call shape the pages already used, but every
// request goes to this app's own server (/api/db, /api/auth) which talks to MongoDB.
import type { Tables } from "./db-types";
type Err = { name?: string; message: string } | null;
type Rows = {
  employees: Tables<"employees"> & { employeeId?: string };
  attendance: Tables<"attendance"> & { employees: { employee_no: string; first_name: string; last_name: string } | null };
  leave_applications: Tables<"leave_applications">;
  leak_reports: Tables<"leak_reports">;
  audit_logs: Tables<"audit_logs">;
  profiles: Tables<"profiles">;
  user_roles: Tables<"user_roles">;
};
type Res<T = any> = { data: T; error: Err; count: number | null };

async function post(url: string, body: unknown): Promise<any> {
  try {
    const r = await fetch(url, { method: "POST", credentials: "same-origin", headers: { "content-type": "application/json" }, body: JSON.stringify(body) });
    const j = await r.json().catch(() => ({}));
    if (!r.ok && !j.error) j.error = { message: `Request failed (${r.status})` };
    return j;
  } catch {
    return { data: null, error: { message: "Can't reach the server" } };
  }
}

class Query<R> implements PromiseLike<Res<R[]>> {
  private req: any;
  constructor(table: string) { this.req = { table, op: "select", filters: [] }; }
  select(cols = "*", opts?: { count?: string; head?: boolean }) {
    if (this.req.op === "select") {
      this.req.join = /employees\(/.test(cols);
      this.req.count = !!opts?.count;
      this.req.head = !!opts?.head;
    }
    return this;
  }
  insert(values: Record<string, unknown>) { this.req.op = "insert"; this.req.values = values; return this; }
  update(values: Record<string, unknown>) { this.req.op = "update"; this.req.values = values; return this; }
  eq(col: string, val: unknown) { this.req.filters.push({ col, op: "eq", val }); return this; }
  neq(col: string, val: unknown) { this.req.filters.push({ col, op: "neq", val }); return this; }
  order(col: string, o?: { ascending?: boolean }) { this.req.order = { col, ascending: o?.ascending ?? true }; return this; }
  limit(n: number) { this.req.limit = n; return this; }
  then<A = Res<R[]>, B = never>(ok?: ((v: Res<R[]>) => A | PromiseLike<A>) | null, bad?: ((e: unknown) => B | PromiseLike<B>) | null) {
    return post("/api/db", this.req)
      .then((j) => ({ data: j.data ?? null, error: j.error ?? null, count: j.count ?? null }))
      .then(ok, bad);
  }
}

export type AppUser = { id: string; email: string; full_name: string; role: "admin" | "hr" | "staff" };
type Listener = (event: "SIGNED_IN" | "SIGNED_OUT") => void;
const listeners = new Set<Listener>();
const emit = (e: "SIGNED_IN" | "SIGNED_OUT") => listeners.forEach((l) => l(e));

export const db = {
  from: <K extends keyof Rows>(table: K) => new Query<Rows[K]>(table),
  rpc: async (fn: string, args: Record<string, unknown>): Promise<Res> => {
    const j = await post("/api/db", { rpc: fn, args });
    return { data: j.data ?? null, error: j.error ?? null, count: null };
  },
  auth: {
    async getUser(): Promise<{ data: { user: AppUser | null }; error: Err }> {
      try {
        const r = await fetch("/api/auth", { credentials: "same-origin", cache: "no-store" });
        const j = await r.json();
        return { data: { user: j.user ?? null }, error: j.error ?? null };
      } catch {
        return { data: { user: null }, error: { message: "Can't reach the server" } };
      }
    },
    async signInWithPassword(c: { email: string; password: string }) {
      const j = await post("/api/auth", { action: "signin", ...c });
      if (!j.error) emit("SIGNED_IN");
      return { error: j.error ?? null };
    },
    async signUp(c: { email: string; password: string; full_name: string }) {
      const j = await post("/api/auth", { action: "signup", ...c });
      return { error: j.error ?? null };
    },
    async signOut() {
      await post("/api/auth", { action: "signout" });
      emit("SIGNED_OUT");
    },
    onAuthStateChange(l: Listener) {
      listeners.add(l);
      return { data: { subscription: { unsubscribe: () => { listeners.delete(l); } } } };
    },
  },
};
