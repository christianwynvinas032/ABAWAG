export function reportCsv(head: string[], rows: (string | null)[][]): string {
  const escape = (value: string | null) => {
    const text = value ?? "";
    const safe = /^[=+@\-\t\r]/.test(text) ? `'${text}` : text;
    return `"${safe.replaceAll('"', '""')}"`;
  };
  return [head, ...rows].map((row) => row.map(escape).join(",")).join("\r\n");
}
