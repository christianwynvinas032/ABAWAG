import { useQuery } from "@tanstack/react-query";
import { db as supabase } from "@/lib/db";

export type AppRole = "admin" | "hr" | "staff";

export function useCurrentUser() {
  return useQuery({
    queryKey: ["current-user"],
    queryFn: async () => {
      const { data, error } = await supabase.auth.getUser();
      if (error && error.name !== "AuthSessionMissingError") throw error;
      const user = data.user;
      if (!user) return null;
      const { data: roles, error: roleError } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", user.id);
      if (roleError) throw roleError;
      const list = (roles ?? []).map((r) => r.role as AppRole);
      return {
        id: user.id,
        email: user.email ?? "",
        roles: list,
        isAdmin: list.includes("admin"),
        isManager: list.includes("admin") || list.includes("hr"),
      };
    },
  });
}

export async function logActivity(action: string, module: string) {
  await supabase.rpc("log_activity", { _action: action, _module: module });
}
