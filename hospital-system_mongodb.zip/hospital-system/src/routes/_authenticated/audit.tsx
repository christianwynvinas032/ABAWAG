import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { requireData } from "@/lib/data-result";
import { db as supabase } from "@/lib/db";
import { Card } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { NoAccess, PageHeader } from "@/components/page";
import { useCurrentUser } from "@/lib/auth";

export const Route = createFileRoute("/_authenticated/audit")({
  head: () => ({ meta: [{ title: "Audit Trail — Hospital Administration" }, { name: "description", content: "Hospital record changes and user activity history." }, { property: "og:title", content: "Audit Trail — Hospital Administration" }, { property: "og:description", content: "Hospital record changes and user activity history." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" }] }),
  component: Audit,
});

const verb: Record<string, string> = { INSERT: "Created record", UPDATE: "Updated record", DELETE: "Deleted record" };

function Audit() {
  const { data: me } = useCurrentUser();
  const { data = [] } = useQuery({
    queryKey: ["audit"],
    enabled: !!me?.isAdmin,
    queryFn: async () => requireData(await supabase.from("audit_logs").select("*").order("created_at", { ascending: false }).limit(500)) ?? [],
  });
  if (me && !me.isAdmin) return <NoAccess />;

  return (
    <div>
      <PageHeader title="Audit Trail" subtitle="Activities performed by users within the system." />
      <Card>
        <Table>
          <TableHeader><TableRow><TableHead>Date &amp; time</TableHead><TableHead>User</TableHead><TableHead>Activity</TableHead><TableHead>Module</TableHead><TableHead>Details</TableHead></TableRow></TableHeader>
          <TableBody>
            {data.map((r) => (
              <TableRow key={r.id}>
                <TableCell className="font-mono text-xs">{new Date(r.created_at).toLocaleString()}</TableCell>
                <TableCell>{r.user_email}</TableCell>
                <TableCell>{verb[r.action] ?? r.action}</TableCell>
                <TableCell>{r.module}</TableCell>
                <TableCell className="text-xs text-muted-foreground">{r.details?.startsWith("Status") ? r.details : ""}</TableCell>
              </TableRow>
            ))}
            {data.length === 0 && <TableRow><TableCell colSpan={5} className="py-10 text-center text-muted-foreground">No activity yet.</TableCell></TableRow>}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
}
