import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Users, CalendarCheck, CalendarDays, Droplets } from "lucide-react";
import { db as supabase } from "@/lib/db";
import { Card } from "@/components/ui/card";
import { PageHeader } from "@/components/page";
import { useCurrentUser } from "@/lib/auth";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({ meta: [{ title: "Dashboard — Hospital Administration" }, { name: "description", content: "Hospital workforce totals, pending leave and unresolved water-system leaks." }, { property: "og:title", content: "Dashboard — Hospital Administration" }, { property: "og:description", content: "Hospital workforce totals, pending leave and unresolved water-system leaks." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" }] }),
  component: Dashboard,
});

function Dashboard() {
  const { data: me } = useCurrentUser();
  const { data } = useQuery({
    queryKey: ["dashboard"],
    queryFn: async () => {
      const today = new Date().toISOString().slice(0, 10);
      const [emp, att, leave, leak] = await Promise.all([
        supabase.from("employees").select("*", { count: "exact", head: true }),
        supabase.from("attendance").select("*", { count: "exact", head: true }).eq("date", today),
        supabase.from("leave_applications").select("*", { count: "exact", head: true }).eq("status", "pending"),
        supabase.from("leak_reports").select("*", { count: "exact", head: true }).neq("status", "resolved"),
      ]);
      const n = (r: { error: unknown; count: number | null }) => (r.error ? "—" : (r.count ?? 0));
      return { emp: n(emp), att: n(att), leave: n(leave), leak: n(leak) };
    },
  });

  const stats = [
    { label: "Total employees", value: data?.emp, icon: Users },
    { label: "Attendance today", value: me?.isManager ? data?.att : "—", icon: CalendarCheck },
    { label: "Pending leave", value: data?.leave, icon: CalendarDays },
    { label: "Unresolved leaks", value: data?.leak, icon: Droplets },
  ];

  return (
    <div>
      <PageHeader title="Dashboard" subtitle={`Welcome back, ${me?.email ?? ""}`} />
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {stats.map((s) => (
          <Card key={s.label} className="p-6">
            <div className="flex items-center justify-between text-muted-foreground">
              <span className="text-sm">{s.label}</span>
              <s.icon className="h-4 w-4 text-primary" />
            </div>
            <p className="mt-4 font-display text-4xl">{s.value ?? "…"}</p>
          </Card>
        ))}
      </div>
    </div>
  );
}
