import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { requireData } from "@/lib/data-result";
import { db as supabase } from "@/lib/db";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { PageHeader, StatusBadge } from "@/components/page";
import { useCurrentUser } from "@/lib/auth";

export const Route = createFileRoute("/_authenticated/leaks")({
  head: () => ({ meta: [{ title: "Leak Detection — Hospital Administration" }, { name: "description", content: "Hospital water-system leak reports and resolution status." }, { property: "og:title", content: "Leak Detection — Hospital Administration" }, { property: "og:description", content: "Hospital water-system leak reports and resolution status." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" }] }),
  component: Leaks,
});

function Leaks() {
  const qc = useQueryClient();
  const { data: me } = useCurrentUser();
  const [f, setF] = useState({ location: "", description: "" });

  const { data: rows = [] } = useQuery({
    queryKey: ["leaks"],
    queryFn: async () => requireData(await supabase.from("leak_reports").select("*").order("created_at", { ascending: false })) ?? [],
  });

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!me) { toast.error("Please sign in again"); return; }
    const { error } = await supabase.from("leak_reports").insert({ ...f, reported_by: me.id, reporter_email: me.email });
    if (error) { toast.error(error.message); return; }
    toast.success("Leak reported");
    setF({ location: "", description: "" });
    qc.invalidateQueries({ queryKey: ["leaks"] });
  }

  async function setStatus(id: string, status: string) {
    const { error } = await supabase.from("leak_reports").update({ status, updated_at: new Date().toISOString() }).eq("id", id);
    if (error) { toast.error(error.message); return; }
    qc.invalidateQueries({ queryKey: ["leaks"] });
  }

  return (
    <div>
      <PageHeader title="Leak Detection" subtitle="Report and monitor water-system leaks within the hospital." />
      <Card className="mb-6 p-6">
        <form onSubmit={submit} className="grid gap-4 md:grid-cols-3">
          <div className="space-y-1.5"><Label>Location</Label><Input placeholder="e.g. 3F East Wing restroom" value={f.location} onChange={(e) => setF({ ...f, location: e.target.value })} required /></div>
          <div className="space-y-1.5 md:col-span-2"><Label>Description</Label><Textarea rows={1} value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} required /></div>
          <Button type="submit" className="md:col-span-3 md:justify-self-end">Submit report</Button>
        </form>
      </Card>
      <Card>
        <Table>
          <TableHeader><TableRow><TableHead>Reported</TableHead><TableHead>Location</TableHead><TableHead>Description</TableHead><TableHead>Reporter</TableHead><TableHead>Status</TableHead></TableRow></TableHeader>
          <TableBody>
            {rows.map((r) => (
              <TableRow key={r.id}>
                <TableCell className="font-mono text-xs">{new Date(r.created_at).toLocaleString()}</TableCell>
                <TableCell className="font-medium">{r.location}</TableCell>
                <TableCell className="max-w-sm">{r.description}</TableCell>
                <TableCell>{r.reporter_email}</TableCell>
                <TableCell>
                  {me?.isManager ? (
                    <Select value={r.status} onValueChange={(v) => setStatus(r.id, v)}>
                      <SelectTrigger className="w-36"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="reported">Reported</SelectItem>
                        <SelectItem value="investigating">Investigating</SelectItem>
                        <SelectItem value="resolved">Resolved</SelectItem>
                      </SelectContent>
                    </Select>
                  ) : <StatusBadge value={r.status} />}
                </TableCell>
              </TableRow>
            ))}
            {rows.length === 0 && <TableRow><TableCell colSpan={5} className="py-10 text-center text-muted-foreground">No leak reports yet.</TableCell></TableRow>}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
}
