import { createFileRoute, Link, Outlet, redirect, useNavigate } from "@tanstack/react-router";
import {
  LayoutDashboard, Users, CalendarCheck, CalendarDays, Droplets, FileText, ShieldCheck, History, LogOut, Cross,
} from "lucide-react";
import { db as supabase } from "@/lib/db";
import { useCurrentUser, logActivity } from "@/lib/auth";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/_authenticated")({
  ssr: false,
  beforeLoad: async () => {
    let signedIn = false;
    try {
      const { data } = await supabase.auth.getUser();
      signedIn = !!data.user;
    } catch {
      signedIn = false;
    }
    if (!signedIn) throw redirect({ to: "/auth" });
  },
  component: Layout,
});

const nav = [
  { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard, need: "any" },
  { to: "/employees", label: "Employees", icon: Users, need: "any" },
  { to: "/attendance", label: "Attendance", icon: CalendarCheck, need: "manager" },
  { to: "/leave", label: "Leave", icon: CalendarDays, need: "any" },
  { to: "/leaks", label: "Leak Detection", icon: Droplets, need: "any" },
  { to: "/reports", label: "Reports", icon: FileText, need: "manager" },
  { to: "/users", label: "User Management", icon: ShieldCheck, need: "admin" },
  { to: "/audit", label: "Audit Trail", icon: History, need: "admin" },
] as const;

function Layout() {
  const { data: me } = useCurrentUser();
  const navigate = useNavigate();
  const items = nav.filter(
    (n) => n.need === "any" || (n.need === "manager" && me?.isManager) || (n.need === "admin" && me?.isAdmin),
  );

  async function signOut() {
    await logActivity("Logged out", "Authentication");
    await supabase.auth.signOut();
    navigate({ to: "/auth" });
  }

  return (
    <div className="flex min-h-screen flex-col md:flex-row">
      <aside className="no-print flex w-full shrink-0 flex-col bg-sidebar text-sidebar-foreground md:sticky md:top-0 md:h-screen md:w-64">
        <div className="flex items-center gap-2 px-6 py-6 text-sidebar-primary">
          <Cross className="h-5 w-5" />
          <span className="font-mono text-xs uppercase tracking-widest">HAHRRS</span>
        </div>
        <nav className="flex flex-wrap gap-1 px-3 md:block md:flex-1 md:space-y-1">
          {items.map((n) => (
            <Link
              key={n.to}
              to={n.to}
              className="flex items-center gap-3 rounded-md px-3 py-2 text-sm text-sidebar-foreground/80 transition-colors hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
              activeProps={{ className: "bg-sidebar-accent text-sidebar-primary" }}
            >
              <n.icon className="h-4 w-4" />
              {n.label}
            </Link>
          ))}
        </nav>
        <div className="border-t border-sidebar-border p-4">
          <p className="truncate text-sm">{me?.email}</p>
          <p className="font-mono text-xs uppercase text-sidebar-primary">{me?.roles.join(", ")}</p>
          <Button variant="ghost" size="sm" onClick={signOut} className="mt-3 w-full justify-start text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground">
            <LogOut className="mr-2 h-4 w-4" /> Log out
          </Button>
        </div>
      </aside>
      <main className="min-w-0 flex-1 overflow-x-auto p-4 md:p-8">
        <Outlet />
      </main>
    </div>
  );
}
