import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { requireData } from "@/lib/data-result";
import { db as supabase } from "@/lib/db";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { PageHeader, StatusBadge } from "@/components/page";
import { useCurrentUser } from "@/lib/auth";

export const Route = createFileRoute("/_authenticated/leave")({
  head: () => ({ meta: [{ title: "Leave — Hospital Administration" }, { name: "description", content: "Leave applications and administrator approvals." }, { property: "og:title", content: "Leave — Hospital Administration" }, { property: "og:description", content: "Leave applications and administrator approvals." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" }] }),
  component: Leave,
});

const types: string[] = ["Sick leave", "Vacation leave", "Emergency leave", "Maternity/Paternity leave", "Other"];

function Leave() {
  const qc = useQueryClient();
  const { data: me } = useCurrentUser();
  const [f, setF] = useState({ leave_type: "Sick leave", start_date: "", end_date: "", reason: "" });

  const { data: rows = [] } = useQuery({
    queryKey: ["leave"],
    queryFn: async () => requireData(await supabase.from("leave_applications").select("*").order("created_at", { ascending: false })) ?? [],
  });

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!me) { toast.error("Please sign in again"); return; }
    if (f.end_date < f.start_date) { toast.error("End date must be on or after start date"); return; }
    const { error } = await supabase.from("leave_applications").insert({ ...f, user_id: me.id, applicant_email: me.email });
    if (error) { toast.error(error.message); return; }
    toast.success("Leave application submitted");
    setF({ leave_type: "Sick leave", start_date: "", end_date: "", reason: "" });
    qc.invalidateQueries({ queryKey: ["leave"] });
  }

  async function setStatus(id: string, status: string) {
    const { error } = await supabase.from("leave_applications").update({ status }).eq("id", id);
    if (error) { toast.error(error.message); return; }
    toast.success(`Application ${status}`);
    qc.invalidateQueries({ queryKey: ["leave"] });
  }

  return (
    <div>
      <PageHeader title="Leave Management" subtitle={me?.isManager ? "Submit and review leave applications." : "Submit leave applications and track their status."} />
      <Card className="mb-6 p-6">
        <form onSubmit={submit} className="grid gap-4 md:grid-cols-3">
          <div className="space-y-1.5">
            <Label>Leave type</Label>
            <Select value={f.leave_type} onValueChange={(v) => setF({ ...f, leave_type: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{types.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5"><Label>Starting date</Label><Input type="date" value={f.start_date} onChange={(e) => setF({ ...f, start_date: e.target.value })} required /></div>
          <div className="space-y-1.5"><Label>Ending date</Label><Input type="date" value={f.end_date} onChange={(e) => setF({ ...f, end_date: e.target.value })} required /></div>
          <div className="space-y-1.5 md:col-span-3"><Label>Reason</Label><Textarea value={f.reason} onChange={(e) => setF({ ...f, reason: e.target.value })} required /></div>
          <Button type="submit" className="md:col-span-3 md:justify-self-end">Submit application</Button>
        </form>
      </Card>
      <Card>
        <Table>
          <TableHeader><TableRow><TableHead>Applicant</TableHead><TableHead>Type</TableHead><TableHead>Dates</TableHead><TableHead>Reason</TableHead><TableHead>Status</TableHead>{me?.isManager && <TableHead>Review</TableHead>}</TableRow></TableHeader>
          <TableBody>
            {rows.map((r) => (
              <TableRow key={r.id}>
                <TableCell>{r.applicant_email}</TableCell>
                <TableCell>{r.leave_type}</TableCell>
                <TableCell className="font-mono text-xs">{r.start_date} → {r.end_date}</TableCell>
                <TableCell className="max-w-xs truncate">{r.reason}</TableCell>
                <TableCell><StatusBadge value={r.status} /></TableCell>
                {me?.isManager && (
                  <TableCell className="space-x-2 whitespace-nowrap">
                    <Button size="sm" variant="outline" disabled={r.status === "approved"} onClick={() => setStatus(r.id, "approved")}>Approve</Button>
                    <Button size="sm" variant="ghost" disabled={r.status === "rejected"} onClick={() => setStatus(r.id, "rejected")}>Reject</Button>
                  </TableCell>
                )}
              </TableRow>
            ))}
            {rows.length === 0 && <TableRow><TableCell colSpan={6} className="py-10 text-center text-muted-foreground">No leave applications yet.</TableCell></TableRow>}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
}
