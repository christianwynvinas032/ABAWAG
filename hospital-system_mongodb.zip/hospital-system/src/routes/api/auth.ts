import { createFileRoute } from "@tanstack/react-router";
import { getDb } from "@/server/mongo.server";
import { clearSessionCookie, createSessionCookie, getSessionUser } from "@/server/session.server";
import { signIn, signUp } from "@/server/handlers.server";

const json = (body: unknown, status = 200, cookie?: string) => {
  const headers = new Headers({ "content-type": "application/json", "cache-control": "no-store" });
  if (cookie) headers.append("set-cookie", cookie);
  return new Response(JSON.stringify(body), { status, headers });
};

export const Route = createFileRoute("/api/auth")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        try {
          const db = await getDb();
          return json({ user: await getSessionUser(db, request) });
        } catch (err) {
          console.error(err);
          return json({ user: null, error: { message: "Database connection failed" } }, 500);
        }
      },
      POST: async ({ request }) => {
        try {
          const db = await getDb();
          const { action, email, password, full_name } = await request.json();
          if (action === "signout") return json({ ok: true }, 200, clearSessionCookie());
          if (action === "signin") {
            const id = await signIn(db, email, password);
            if (!id) return json({ error: { message: "Invalid email or password" } }, 401);
            return json({ ok: true }, 200, createSessionCookie(id));
          }
          if (action === "signup") {
            try {
              await signUp(db, email, password, full_name);
            } catch (e) {
              return json({ error: { message: (e as Error).message } }, 400);
            }
            return json({ ok: true });
          }
          return json({ error: { message: "Unknown action" } }, 400);
        } catch (err) {
          console.error(err);
          return json({ error: { message: "Database connection failed. Check MONGODB_URI." } }, 500);
        }
      },
    },
  },
});
