import { createFileRoute } from "@tanstack/react-router";
import { getDb } from "@/server/mongo.server";
import { getSessionUser } from "@/server/session.server";
import { handleDb, handleRpc } from "@/server/handlers.server";

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { "content-type": "application/json" } });

export const Route = createFileRoute("/api/db")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        try {
          const db = await getDb();
          const user = await getSessionUser(db, request);
          if (!user) return json({ data: null, error: { message: "Please sign in again" } }, 401);
          const body = await request.json();
          const res = body.rpc ? await handleRpc(db, user, body.rpc, body.args ?? {}) : await handleDb(db, user, body);
          return json({ data: res.data, error: res.error, count: res.count ?? null }, res.status ?? 200);
        } catch (err) {
          console.error(err);
          return json({ data: null, error: { message: "Database error. Check MONGODB_URI and Atlas network access." } }, 500);
        }
      },
    },
  },
});
