import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { Cross } from "lucide-react";
import { db as supabase } from "@/lib/db";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { logActivity } from "@/lib/auth";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { title: "Sign in — Hospital Administration System" },
      { name: "description", content: "Sign in with your registered email and password." },
      { property: "og:title", content: "Sign in — Hospital Administration System" },
      { property: "og:description", content: "Sign in with your registered email and password." },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"in" | "up">("in");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      if (mode === "in") {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        await logActivity("Logged in", "Authentication");
        navigate({ to: "/dashboard" });
      } else {
        const { error } = await supabase.auth.signUp({ email, password, full_name: fullName });
        if (error) throw error;
        toast.success("Account created. You can now sign in.");
        setMode("in");
      }
    } catch (err) {
      toast.error((err as Error).message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      <div className="hidden flex-col justify-between bg-sidebar p-12 text-sidebar-foreground lg:flex">
        <div className="flex items-center gap-2 text-sidebar-primary">
          <Cross className="h-6 w-6" />
          <span className="font-mono text-sm uppercase tracking-widest">HAHRRS</span>
        </div>
        <div>
          <h1 className="text-5xl leading-tight text-sidebar-accent-foreground">
            Hospital Administration, Human Resources &amp; Reporting
          </h1>
          <p className="mt-6 max-w-md text-sidebar-foreground/70">
            Employees, attendance, leave, water-system leaks and audit trail — in one organized place.
          </p>
        </div>
        <p className="font-mono text-xs text-sidebar-foreground/50">Authorized personnel only</p>
      </div>
      <div className="flex items-center justify-center p-6">
        <form onSubmit={submit} className="w-full max-w-sm space-y-5">
          <div>
            <h2 className="text-3xl">{mode === "in" ? "Sign in" : "Create account"}</h2>
            <p className="mt-1 text-sm text-muted-foreground">
              {mode === "in" ? "Enter your registered email and password." : "Register a new system account."}
            </p>
          </div>
          {mode === "up" && (
            <div className="space-y-2">
              <Label htmlFor="name">Full name</Label>
              <Input id="name" value={fullName} onChange={(e) => setFullName(e.target.value)} required />
            </div>
          )}
          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="password">Password</Label>
            <Input id="password" type="password" minLength={8} value={password} onChange={(e) => setPassword(e.target.value)} required />
          </div>
          <Button type="submit" className="w-full" disabled={busy}>
            {busy ? "Please wait…" : mode === "in" ? "Sign in" : "Create account"}
          </Button>
          <button
            type="button"
            className="w-full text-center text-sm text-muted-foreground hover:text-foreground"
            onClick={() => setMode(mode === "in" ? "up" : "in")}
          >
            {mode === "in" ? "No account yet? Register" : "Already registered? Sign in"}
          </button>
        </form>
      </div>
    </div>
  );
}
